import java.util.*;

public class Spielfeld
{
    private String name;
    private double flaeche;
    private String spielmodus;
    private int maxSpieler;
    private ArrayList<Spielfeld> spielfeld = new ArrayList<>();
    
  
    public Spielfeld(String name, double flaeche, String spielmodus, int maxSpieler)
    {
       setName(name);
       setFlaeche(flaeche);
       setSpielmodus(spielmodus);
       setmaxSpieler(maxSpieler);
       
    }

    
    
    private void setName(String name){
        this.name = name;
    }
    public String getName(){
        return this.name;
    }
    
    private void setFlaeche(double flaeche){
        this.flaeche = flaeche ;
    }
    public double getFlaeche(){
        return this.flaeche;
    }
    
    private void setSpielmodus(String spielmodus){
        this.spielmodus = spielmodus;
    }
    public String getSpielmodus(){
        return this.spielmodus;
    }
    
    private void setmaxSpieler(int maxSpieler){
        this.maxSpieler = maxSpieler;
    }
    public int getmaxSpieler(){
        return this.maxSpieler;
    }
    
    
}
