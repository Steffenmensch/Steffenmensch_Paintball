import java.util.*;
public class Verwalter extends Mensch
{
    private ArrayList<Spielfeld> spielfeld = new ArrayList<>();
    
    
    public Verwalter(String vorname, String zuname, int alter, boolean zettelE)
    {
        super(vorname, zuname, alter, zettelE);
    }

    private void setSpielfeld(ArrayList spielfeld)
    {
        this.spielfeld = spielfeld;
    }
    public ArrayList getSpielfeld()
    {
        return this.spielfeld;
    }
    
    public void spielfeldHinzufuegen(Spielfeld spielfeld){
        
        if(getSpielfeld().size() <= 8)
        {
            getSpielfeld().add(spielfeld);
        }
    }
}
