
import java.util.*;
public class Buchungen
{
    
    private Kunde kunde;
    private ArrayList<zeitSlots> zeitSlots = new ArrayList<>();
    /**
     * Constructor for objects of class Buchungen
     */
    public Buchungen()
    {
        setKunde(kunde);
        
        
    }
    
    private void setKunde(Kunde kunde){
        this.kunde = kunde;
    }
    public Kunde getKunde(){
        return this.kunde;
    }
    
    private void setZeitSlots(ArrayList<zeitSlots> zeitSlots){
        this.zeitSlots = zeitSlots;
    }
    public ArrayList zeitSlots(){
        return this.zeitSlots;
    }
    
    public void zeitSlotsBuchen()
    {
        
    }
}
