

public class zeitSlots
{
    
    public zeitSlots()
    {
        
    }

    
}
