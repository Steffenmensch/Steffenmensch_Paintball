
public class Kunde extends Mensch
{
 

    public Kunde(String vorname, String zuname, int alter, boolean zettelE)
    {
        super(vorname, zuname, alter, zettelE);
    }


}
