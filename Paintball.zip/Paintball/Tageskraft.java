
public class Tageskraft extends Mensch
{

 
    public Tageskraft(String vorname, String zuname, int alter, boolean zettelE)
    {
        super(vorname, zuname, alter, zettelE);
    }


}
