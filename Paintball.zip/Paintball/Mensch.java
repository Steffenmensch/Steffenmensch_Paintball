
public abstract class Mensch
{
    // instance variables - replace the example below with your own
    private String vorname;
    private String zuname;
    private int alter;
    private boolean zettelE;
    
    public Mensch(String vorname, String zuname, int alter, boolean zettelE){
        setVorname(vorname);
        setZuname(zuname);
        setAlter(alter);
        setZettelE(zettelE);
    
    }
    
    
    private void setVorname(String vorname){
        this.vorname = vorname;
    }
    public String getVorname(){
        return this.vorname;
    }
    
    private void setZuname(String zuname){
        this.zuname = zuname;
    }
    public String getZuname(){
        return this.zuname;
    }

    private void setAlter(int alter){
        this.alter = alter;
    }
    public int getAlter(){
        return this.alter;
    }
    
    private void setZettelE(boolean zettelE){
        this.zettelE = zettelE;
    }
    public boolean getZettelE(){
        return this.zettelE;
    }
    
    
    
}
